#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void unique(char** words, int n){
    int count = 1;
    for(int i = 0; i < n - 1; i++){
        if(strcmp(*(words + i), *(words + (i + 1))) == 0){
           count++; 
        }else{
           printf("%d %s", count, *(words + i));
           count = 1;
        }
        
        if((i+1) == (n-1)){
           printf("%d %s", count, *(words + (i + 1))); 
        }
    }
    
    if(n == 1){
        printf("%d %s", count, *words);
    }
}

int main(int argc, char* argv[])
{
    char** strings = malloc(sizeof(char*));
    int count = 0;
    
    char* input = NULL;
    size_t size = 0;
    
    getline(&input, &size, stdin);
    
    while(!feof(stdin)){       
        count++;
        strings = (char**)realloc(strings, count*sizeof(char*));        
        *(strings + (count - 1)) = (char*)malloc(size*sizeof(char));
        strcpy(*(strings + (count - 1)), input);
        getline(&input, &size, stdin);       
    }
    
    unique(strings, count);
        
    free(strings);
}
