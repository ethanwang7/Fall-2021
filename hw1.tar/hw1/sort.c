#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void sort(char** words, int n, size_t max){
    char* temp = (char*)malloc(max*sizeof(char));
    for(int i = 0; i < n - 1; i++){
        for(int j = 0; j < n - i - 1; j++){
            if(strcasecmp(*(words + j), *(words + (j + 1))) > 0){                              
                strcpy(temp, *(words + j));
                strcpy(*(words + j), *(words + (j + 1)));
                strcpy(*(words + (j + 1)), temp);
            }
        }
    }
}

void intSort(int* num, int n){
    int* temp = (int*)malloc(sizeof(int));
    for(int i = 0; i < n - 1; i++){
        for(int j = 0; j < n - i - 1; j++){
            if(*(num + j) > *(num + (j + 1))){                              
                *temp = *(num + j);
                *(num + j) = *(num + (j + 1));
                *(num + (j + 1)) = *temp;
            }
        }
    }    
}

int main(int argc, char* argv[])
{
    char** strings = malloc(sizeof(char*));
    int* numbers = malloc(sizeof(int));
    int count = 0;
    
    char* input = NULL;
    int input2 = 0;
    size_t size = 0;
    size_t maxSize = 0;
    
    getline(&input, &size, stdin);
    
    if((argc > 1) && (strcmp(argv[1], "-n") == 0)){
        while(!feof(stdin)){
            input2 = atoi(input);
            count++;
            numbers = realloc(numbers, count*sizeof(int));
            *(numbers + (count - 1)) = input2;
            getline(&input, &size, stdin);
        }
        
        intSort(numbers, count);
        for(int h = 0; h < count; h++){
            printf("%d\n", *(numbers + h));
        }              
    }else{    
        while(!feof(stdin)){       
            count++;  
            strings = realloc(strings, count*sizeof(char*));      
            *(strings + (count - 1)) = (char*)malloc(size*sizeof(char));
            strcpy(*(strings + (count - 1)), input);
            getline(&input, &size, stdin);
            if(size > maxSize){
                maxSize = size;
            }          
            
        }
        sort(strings, count, maxSize);
        for(int k = 0; k < count; k++){
            printf("%s", *(strings + k));
        }
    }       
        
    free(strings);
    free(numbers);
}
