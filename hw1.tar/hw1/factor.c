#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    int n = atoi(argv[1]);
    
    if(n == 0){
        printf("%d\n", 0);
        exit(0);
    }

    while(n % 2 == 0){
        if(n == 2){
            printf("%d\n", 2);
        }else{
            printf("%d ", 2);
        }
        n = n/2;
    }
    
    for(int i = 3; i <= n/2; i = i + 2){
        while(n % i == 0){
            if(n == i){
                printf("%d\n", i);
            }else{
                printf("%d ", i);
            }
            n = n/i;
        }
    }
    
    if(n > 2){
        printf("%d\n", n);
    }
}
