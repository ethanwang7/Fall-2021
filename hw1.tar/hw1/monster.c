#include <stdio.h>
#include <stdlib.h>

void printGrid(int x, int y, char grid[y][x]){
    for(int k = y; k > 0; k--){
        for(int h = 0; h < x; h++){
            printf("%c ", grid[k-1][h]);
        }
        printf("\n");
    }   
}

void checkBounds(int bX, int bY, int x, int y){
    if((x < 0) || (x >= bX) || (y < 0) || (y >= bY)){
        exit(0);
    }
}

int main(int argc, char* argv[])
{
    int boardX = atoi(argv[1]);
    int boardY = atoi(argv[2]);
    int plrX = atoi(argv[3]);
    int plrY = atoi(argv[4]);
    int goalX = atoi(argv[5]);
    int goalY = atoi(argv[6]);
    int monX = atoi(argv[7]);
    int monY = atoi(argv[8]);
    
    if((boardX <= 0) || (boardY <= 0)){
        exit(0);
    }
    
    checkBounds(boardX, boardY, plrX, plrY);//check if dimensions are out of bounds
    checkBounds(boardX, boardY, monX, monY);
    checkBounds(boardX, boardY, goalX, goalY);
    
    if((monX == plrX) && (monY == plrY)){//case when player or monster wins on input
        printf("monster wins!\n");
        exit(0);
    }else if((plrX == goalX) && (plrY == goalY)){
        printf("player wins!\n");
        exit(0);
    }    
    
    char grid[boardY][boardX];
    
    for(int i = 0; i < boardY; i++){
        for(int j = 0; j < boardX; j++){
            if((i == plrY) && (j == plrX)){
                grid[i][j] = 'P';
            }else if((i == monY) && (j == monX)){
                grid[i][j] = 'M';
            }else if((i == goalY) && (j == goalX)){
                grid[i][j] = 'G';
            }else{
                grid[i][j] = '.';
            }
        }
    }
    
    printGrid(boardX, boardY, grid);
   
    char* direction;
    size_t size = 0;
    
    getline(&direction, &size, stdin); 
    
    while(!feof(stdin)){                
        if((*direction == 'N') || (*direction == 'n')){
            plrY++;
            grid[plrY-1][plrX] = '.';          
        }else if((*direction == 'E') || (*direction == 'e')){
            plrX++;
            grid[plrY][plrX-1] = '.';            
        }else if((*direction == 'S') || (*direction == 's')){
            plrY--;
            grid[plrY+1][plrX] = '.';            
        }else if((*direction == 'W') || (*direction == 'w')){
            plrX--;
            grid[plrY][plrX+1] = '.';                      
        }
        
        if((plrX < 0) || (plrY < 0) || (plrX == boardX) || (plrY == boardY)){//out of bounds
            break;
        }
        grid[plrY][plrX] = 'P';
        
        if((monX == plrX) && (monY == plrY)){//player moves to monster
            printf("monster wins!\n");
            break;
        }else if((plrX == goalX) && (plrY == goalY)){
            printf("player wins!\n");
            break;
        }
              
        int monDistX = abs(monX - plrX);
        int monDistY = abs(monY - plrY);
        
        if((monDistY >= monDistX)){
            if(monY > plrY){
                monY--;
                grid[monY+1][monX] = '.';
                printf("monster moves S\n");
            }else if(monY < plrY){
                monY++;
                grid[monY-1][monX] = '.';
                printf("monster moves N\n");
            }
        }else{
            if(monX > plrX){
                monX--;
                grid[monY][monX+1] = '.';
                printf("monster moves W\n");
            }else if(monX < plrX){
                monX++;
                grid[monY][monX-1] = '.';
                printf("monster moves E\n");
            }            
        }
        grid[monY][monX] = 'M';
                
        if((monX == plrX) && (monY == plrY)){
            printf("monster wins!\n");
            break;
        }
        
        if(grid[goalY][goalX] == '.'){
            grid[goalY][goalX] = 'G';
        }
        
        printGrid(boardX, boardY, grid);
                       
        getline(&direction, &size, stdin);       
    }    
}
