#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void lowerCase(char* input){
   for(int i = 0; i < strlen(input); i++){
       *(input + i) = tolower(*(input + i));
   }
}

int main(int argc, char* argv[])
{
    char* input = argv[1];
    char* cmp = NULL;
    size_t size = 0;
       
    getline(&cmp, &size, stdin);
    
    if((argc > 2) && (strcmp(argv[1], "-i") == 0)){//case insensitive
        input = argv[2];
        lowerCase(input);
                
        char* original = strcpy(original, cmp);//preserves the original string  
                   
        while(!feof(stdin)){
            strcpy(original, cmp);
            lowerCase(cmp);     
            if(strstr(cmp, input) != NULL){
                printf("%s", original);
            }
            getline(&cmp, &size, stdin);            
        }
        
    }else{//case sensitive
        while(!feof(stdin)){       
            if(strstr(cmp, input) != NULL){
                printf("%s", cmp);
            }
            getline(&cmp, &size, stdin); 
        }
    }
    
}
