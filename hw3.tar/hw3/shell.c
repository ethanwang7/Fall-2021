#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

typedef struct Job
{
    int id;
    pid_t pid;
    char* status;
    char* path[100];
    int background;
} Job;

Job joblist[1000];
int jobs = 0;
int status;

void siginthandler(int sig){
    jobs--;
    joblist[jobs].status = "";
    write(STDOUT_FILENO, "\n", 2);  
}

void sigtstphandler(int sig){ 
    write(STDOUT_FILENO, "\n", 2);   
}

void sigchldhandler(int sig){
 
}

void printJob(int id, int pid, char* status, char* path[], int background){
    if((strcmp(status, "Running") == 0) || (strcmp(status, "Stopped") == 0)){
        printf("[%d] ", id);
        printf("%d ", pid);
        printf("%s ", status);
        for(int j = 0; j < 100; j++){
            if(path[j] == NULL){
                break;
            }            
            printf("%s ", path[j]);            
        }
        if(background == 1){
            printf("&");
        }
        printf("\n");
    }     
}


int main(int argc, char* argv[]){
    char* path = NULL;
    size_t size = 0;
    char* list[100];
        
    signal(SIGINT, siginthandler);
    signal(SIGTSTP, sigtstphandler);
    printf("> ");
    getline(&path, &size, stdin);
    
    while(!feof(stdin)){
        status = 0;        
        int background = 0;       
        for(int i = 0; i < 100; i++){          
            list[i] = strsep(&path, " ");
            list[i] = strsep(&list[i], "\n");

            if (list[i] == NULL){
                break;
            }
            if(strcmp(list[i], "&") == 0){
                background++;
                list[i] = NULL;
                break;
            }
        }

        pid_t pid = fork();//necessary to keep running the shell
        
        if(pid == 0) {
            if(strcmp(list[0], "kill") == 0){
                exit(0);
            }
        
            if((execvp(list[0], list) < 0) && (strcmp(list[0], "cd") != 0)
            && (strcmp(list[0], "fg") != 0) && (strcmp(list[0], "bg") != 0)
            && (strcmp(list[0], "exit") != 0) && (strcmp(list[0], "jobs") != 0)){
                if((strchr(list[0], '/')) == NULL){
                    printf("%s: command not found\n", list[0]);   
                }else{                  
                    printf("%s: No such file or directory\n", list[0]);
                }               
            }           

            exit(0);
        } else { 
            signal(SIGCHLD, sigchldhandler);
            if(strcmp(list[0], "cd") == 0){
                chdir(list[1]);
                setenv("PWD", list[1], 1);
                jobs++;
            }else if(strcmp(list[0], "jobs") == 0){
                for(int j = 0; j < 1000; j++){
                    if(joblist[j].status != NULL){
                        printJob(joblist[j].id, joblist[j].pid, joblist[j].status, joblist[j].path, joblist[j].background);
                    }
                }
                jobs++;
            }else if(strcmp(list[0], "bg") == 0){
                int jobIndex = atoi(&list[1][1])-1;
                
                if(strcmp(joblist[jobIndex].status, "Stopped") == 0){
                    kill(joblist[jobIndex].pid, SIGCONT);
                    joblist[jobIndex].status = "Running";
                    joblist[jobIndex].background = 1;                                        
                }
                jobs++;
            }else if(strcmp(list[0], "fg") == 0){
                int jobIndex = atoi(&list[1][1])-1;
                
                kill(joblist[jobIndex].pid, SIGCONT);
                joblist[jobIndex].background = 0;
                waitpid(joblist[jobIndex].pid, &status, WUNTRACED);
                jobs++;
                if(WIFSTOPPED(status)){
                    joblist[jobIndex].status = "Stopped";
                }            
            }else if(strcmp(list[0], "exit") == 0){
                for(int h = 0; h < jobs; h++){
                    if(strcmp(joblist[h].status, "Stopped")){
                        kill(joblist[h].pid, SIGCONT);
                    }
                    kill(joblist[h].pid, SIGHUP);
                }
                exit(0);
            }else if(strcmp(list[0], "kill") == 0){
                int jobIndex = atoi(&list[1][1])-1;
            
                kill(joblist[jobIndex].pid, SIGCONT);
                kill(joblist[jobIndex].pid, SIGTERM);
                waitpid(joblist[jobIndex].pid, &status, WUNTRACED);
                printf("%d terminated by signal 15\n", joblist[jobIndex].pid);
                joblist[jobIndex].status = "";
                free(joblist[jobIndex].path[0]);
                if(jobs == 1){
                    jobs--;
                }
            }else{          
                joblist[jobs].id = jobs+1;   
                joblist[jobs].pid = pid;
                joblist[jobs].status = "Running";
                for(int k = 0; k < 100; k++){
                    joblist[jobs].path[k] = list[k];

                    if (list[k] == NULL){
                        break;
                    }
                }
                jobs++;                                            
            }
            
            if(background == 0){
                waitpid(pid, &status, WUNTRACED);//run program in foreground
            }else{
                printf("[%d] %d\n", joblist[jobs-1].id, joblist[jobs-1].pid);
                joblist[jobs-1].background = 1;
            }
        }
        
        if(WIFSTOPPED(status)){
            joblist[jobs-1].status = "Stopped";
            if(strcmp(list[0], "fg") == 0){
                status = 0;
            }
        }               
        
        if((WIFEXITED(status)) && (background == 0)){
            free(list[0]);
            if(jobs > 0){
                jobs--; 
            }          
        }
        
        printf("> ");
        getline(&path, &size, stdin);
    }
    printf("\n");
    free(path);
}
