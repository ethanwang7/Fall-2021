#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

void find(char *dr, char *pattern){
    char *path = (char*)malloc(1000*sizeof(char));
    struct dirent *dp;
    DIR *dir = opendir(dr);
    
    if(!dir){
        free(path);
        return;
    }
    
    while ((dp = readdir(dir)) != NULL){
        if ((strcmp(dp->d_name, ".") != 0) && (strcmp(dp->d_name, "..") != 0)){
            
            strcpy(path, dr);
            strcat(path, "/");
            strcat(path, dp->d_name);
            
            if(strstr(dp->d_name, pattern) != NULL){
                printf("%s\n", path);
            }

            find(path, pattern);
        }
    }
    
    free(path);
    closedir(dir);
}

int main(int argc, char* argv[]){
    char* input = NULL;
    
    if(argc < 2){
        exit(0);
    }else{
        input = argv[1];
    }
    
    
    find(".", input);
}
