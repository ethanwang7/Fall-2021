#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pwd.h>
#include <grp.h>

void sort(struct dirent **files, int n){
    char *temp = (char*)malloc(255*sizeof(char));    
    for(int i = 0; i < n - 1; i++){
        for(int j = 0; j < n - i - 1; j++){
            if(strcasecmp(files[j]->d_name, files[(j+1)]->d_name) > 0){                             
                strcpy(temp, files[j]->d_name); 
                strcpy(files[j]->d_name, files[(j+1)]->d_name);
                strcpy(files[(j+1)]->d_name, temp);
            }
        }
    }
    free(temp);
}

int main(int argc, char* argv[]){
    struct dirent **namelist;
    int n;
    
    if(argc < 1){
        exit(0);
    }else if (argc >= 1){
        n = scandir(".", &namelist, NULL, alphasort);
    }  
        
    if(n < 0){
        exit(0);   
    }else{
        for(int k = 0; k < n; k++){
            namelist[k] = realloc(namelist[k], sizeof(struct dirent));
        }
        sort(namelist, n); 
        if((argc > 1) && (strcmp(argv[1], "-l") == 0)){
            int j = 0;
            while(j < n){            
                struct stat fileStat;
                char *time = (char*)malloc(20*sizeof(char));
                
                if(stat(namelist[j]->d_name, &fileStat) < 0){
                    break;
                }
                
                if((strcmp(namelist[j]->d_name, ".") != 0) && (strcmp(namelist[j]->d_name, "..") != 0)){
                    printf((S_ISDIR(fileStat.st_mode)) ? "d" : "-");
                    printf((fileStat.st_mode & S_IRUSR) ? "r" : "-");
                    printf((fileStat.st_mode & S_IWUSR) ? "w" : "-");
                    printf((fileStat.st_mode & S_IXUSR) ? "x" : "-");
                    printf((fileStat.st_mode & S_IRGRP) ? "r" : "-");
                    printf((fileStat.st_mode & S_IWGRP) ? "w" : "-");
                    printf((fileStat.st_mode & S_IXGRP) ? "x" : "-");
                    printf((fileStat.st_mode & S_IROTH) ? "r" : "-");
                    printf((fileStat.st_mode & S_IWOTH) ? "w" : "-");
                    printf((fileStat.st_mode & S_IXOTH) ? "x" : "-");
                    printf(" %s ", getpwuid(fileStat.st_uid)->pw_name);
                    printf("%s ", getgrgid(fileStat.st_gid)->gr_name);
                    printf("%ld ", fileStat.st_size);
                    strftime(time, 20, "%b %d %H:%M", localtime(&(fileStat.st_mtime)));
                    printf("%s ", time);
                    printf("%s\n", namelist[j]->d_name);
                }
                free(time);
                free(namelist[j]);
                j++;
            }
        }else{
            int i = 0;
            while(i < n){
                if((strcmp(namelist[i]->d_name, ".") != 0) && (strcmp(namelist[i]->d_name, "..") != 0)){
                    printf("%s\n", namelist[i]->d_name);
                }
                free(namelist[i]);
                i++;
            }
        }
    }
    
    free(namelist);
}
