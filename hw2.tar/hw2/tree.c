#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

void sort(struct dirent **files, int n){
    char *temp = (char*)malloc(255*sizeof(char));    
    for(int i = 0; i < n - 1; i++){
        for(int j = 0; j < n - i - 1; j++){
            if(strcasecmp(files[j]->d_name, files[(j+1)]->d_name) > 0){                             
                strcpy(temp, files[j]->d_name); 
                strcpy(files[j]->d_name, files[(j+1)]->d_name);
                strcpy(files[(j+1)]->d_name, temp);
            }
        }
    }
    free(temp);
}

void tree(char *dr, int spaces){
    char *path = (char*)malloc(1000*sizeof(char));
    DIR *dir = opendir(dr);
    
    if(!dir){
        free(path);
        return;
    }
    
    struct dirent **namelist;
    int n = scandir(dr, &namelist, NULL, alphasort);
    
    if(n < 0){
        free(path);
        return;
    }else{
        for(int k = 0; k < n; k++){
            namelist[k] = realloc(namelist[k], sizeof(struct dirent));
        }
        sort(namelist, n);   
    }
    
    for(int i = 0; i < n; i++){
       if((strcmp(namelist[i]->d_name, ".") != 0) && (strcmp(namelist[i]->d_name, "..") != 0)){
           for(int j = 0; j < spaces; j++){
               printf(" ");
           }
           
           printf("- %s\n", namelist[i]->d_name);
       
           strcpy(path, dr);
           strcat(path, "/");
           strcat(path, namelist[i]->d_name);
           free(namelist[i]);
           tree(path, (spaces+2));                  
       }else{
           free(namelist[i]);
       }
       
    }
    
    free(namelist);
    free(path);
    closedir(dir);
}

int main(int argc, char* argv[]){
    printf(".\n");
    tree(".", 0);
    
}
